System.register("virtual:///prerequisite-imports/tao_bao_avatar_res", [], (function () { "use strict"; return { execute: function () { } } }));

'use strict';
module.exports = {
    zh: `1.修复性别显示错误,2.添加头发染色功能`,
    en: `1. fix gender display error. 2. add hair color`
};
'use strict';

module.exports = {
    "miss_param_tips": "请在 Service 面板设置好 agora 的 AppID ",
};
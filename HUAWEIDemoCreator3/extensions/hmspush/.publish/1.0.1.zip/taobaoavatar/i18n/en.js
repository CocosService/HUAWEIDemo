'use strict';

module.exports = {
    "miss_param_tips": "Please set the AppID of agora in the Service Panel.",
};